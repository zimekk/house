(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-1fa4813b.js")
    );
  })().catch(console.error);

})();
